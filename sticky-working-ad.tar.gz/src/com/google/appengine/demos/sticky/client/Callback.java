package com.google.appengine.demos.sticky.client;

public interface Callback {
    public void callback();
}
