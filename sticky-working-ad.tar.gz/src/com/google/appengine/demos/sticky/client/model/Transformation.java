package com.google.appengine.demos.sticky.client.model;

import java.io.Serializable;

public enum Transformation implements Serializable {
	CROP, ROT_C, ROT_CC, FLIP_H, FLIP_V, NONE
}